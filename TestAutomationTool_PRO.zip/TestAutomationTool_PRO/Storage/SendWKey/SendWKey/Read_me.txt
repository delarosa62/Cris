Author: BlueLife , Velociraptor
www.sordum.org


############-- Send Windows Key v1.1 --############
(Thursday, 11 November 2021)

Changelog:

1. [ Added ] - A different key can be send
2. [ Added ] - /Wait: parameter
3. [ Added ] - Some code improvements

---------------------------------------------------------------

############-- Send Windows Key v1.0 --############
(Thursday, 13 August 2020)

Send Windows key is a very simple Portable freeware and helps to run the keyboard key combination which using with the windows key





