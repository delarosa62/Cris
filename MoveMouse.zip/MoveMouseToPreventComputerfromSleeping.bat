echo hello
pause 5
exit
