
let currentData = ''
let searchUpdate = ''
let personBranch = ''
let skill = ''

/*localStorage.setItem('master-key', '')
localStorage.setItem('ft', '')
localStorage.setItem('saved', '')
localStorage.setItem('skills', '')
localStorage.setItem('SG', '')*/

//alert(localStorage.getItem('SG'))
//alert(localStorage.getItem('skills'))

localStorage.setItem('ft', 1)

let fstTime = localStorage.getItem('ft')
let profileSaved = localStorage.getItem('saved')

if(1*profileSaved === 1){

    fstTime = 2
    localStorage.setItem('ft', 2)

    profileSaved = 0
    localStorage.setItem('saved', 0)

}

if (localStorage.getItem('skills') === null || localStorage.getItem('skills') === 'null'){

    localStorage.setItem('skills', '')
}

// Event Listeners

document.getElementById('registerBtn').addEventListener('click', () => {

    searchUpdate = ''
    showRegisterForm()
});

document.getElementById('viewBtn').addEventListener('click', showViewForm);
document.getElementById('updateBtn').addEventListener('click', showUpdateForm);
document.getElementById('deleteBtn').addEventListener('click', deleteStudentProfile);

document.getElementById('home-btn').addEventListener('click', () => {

    disableLogin()
    houseKeeping()
    disableSearchPage()

    document.getElementById('home-btn').style.display = 'none'

 })

document.getElementById('register-btn').addEventListener('click', () => {
    
    saveProfile()

 })

 document.getElementById('itaic').addEventListener('click', () => {
    
    document.getElementById("initial-page").style.display = 'block'
    document.getElementById("logo-page").style.display = 'block'

    document.getElementById("emaic").style.display = 'none'
    document.getElementById("itaic").style.display = 'block'

    skill = ''

 })

 document.getElementById('emaic').addEventListener('click', () => {
    
    document.getElementById("initial-page").style.display = 'none'
    document.getElementById("logo-page").style.display = 'block'

    document.getElementById("itaic").style.display = 'none'
    document.getElementById("emaic").style.display = 'block'
    document.getElementById("emaic-options-page").style.display = 'block'

//=====================
/*
    document.getElementById("initial-page").style.display = 'block'
    document.getElementById("registerBtn").style.display = 'block'
    document.getElementById("viewBtn").style.display = 'none'
    document.getElementById("updateBtn").style.display = 'none'
    document.getElementById("deleteBtn").style.display = 'none'

    document.getElementById("backup-btn").style.display = 'none'

    document.getElementById("textarea").style.display = 'none'
    document.getElementById("recover-data-btn").style.display = 'none'
    document.getElementById("back-home").style.display = 'none'
*/
//============================

    skill = 'emaic'

 })

 document.getElementById('cursos-generales-btn').addEventListener('click', (e) => {

    displayEmaicMenu(e.target.id)

 })

 document.getElementById('evangelismo-btn').addEventListener('click', (e) => {

    displayEmaicMenu(e.target.id)

 })

 document.getElementById('pastorado-btn').addEventListener('click', (e) => {

     displayEmaicMenu(e.target.id)
 })

 document.getElementById('magisterio-btn').addEventListener('click', (e) => {

     displayEmaicMenu(e.target.id)

 })


 document.getElementById('back-home').addEventListener('click', () => {
    
    displayLogoPage()

 })

 document.getElementById('back-home-btn').addEventListener('click', () => {
    
    displayLogoPage()
 })


 document.getElementById('register-btn1').addEventListener('click', () => {

    disableLogin()

    if(currentData !== ''){

       let studentID = currentData.split(':')[0]

       if(searchUpdate === 1){

        deleteCurrentData(currentData.split(':')[0])
       }

       else if (searchUpdate === 2){ //This condition will never be met. But just in case!!
         return
       }

       localStorage.setItem('SG', localStorage.getItem('SG') + currentData)
       currentData = ''

       alert('Información guardada correctamente!!. Pulse Ok para seguir!!')

       profileSaved = 1
       localStorage.setItem('saved', 1)

       if(skill !== '') {

            localStorage.setItem('skills', localStorage.getItem('skills') + '===' + studentID + '|' + skill)

       }

    }
    
    houseKeeping()

 })

 document.getElementById('search-btn').addEventListener('click', () => {

    disableLogin()

    if (searchUpdate === 0){
        getStudentsData()
    }
    else if (searchUpdate === 1){
        updateStudentsData()
    }
    else if (searchUpdate === 2){
        deleteCurrentData('dummyValue')
    }


 })

 document.getElementById('new-search-btn').addEventListener('click', () => {

    disableLogin()
 
    showRegisterForm()
    displaySearchPage()

    document.getElementById("new-search-btn").style.display = 'none'
    document.getElementById("search-btn").style.display = 'block'
    document.getElementById("new-search-label").innerHTML = 'Datos del estudiante en curso'

 })


 document.getElementById('backup-btn').addEventListener('click', () => {
    
    backUp()

 })

 document.getElementById('recover-data-btn').addEventListener('click', () => {
    
    dataRecovery()

 })


// Functions
function showRegisterForm() {
    // Display registration form in registerModal

    document.getElementById("registrationForm").style.display = 'block'
    document.getElementById('home-btn').style.display = 'block'

    if(searchUpdate === ''){
        document.getElementById('studentID').value = ''
    }

    setFormLabel(document.getElementById('studentID').value)

    removeHomePageButtons()


}

function showViewForm() {
    // Display view form in viewModal

    searchUpdate = 0
    processForm()
}

function showUpdateForm() {
    // Display update form in updateModal
    searchUpdate = 1
    processForm()
 
}

function deleteStudentProfile() {
    // Logic to delete student profile
    searchUpdate = 2
    processForm()

}

function houseKeeping(){

    try{

        document.getElementById("registrationForm").style.display = 'none'
        document.getElementById('register-btn').style.display = 'none'
        document.getElementById('register-btn1').style.display = 'none'
        document.getElementById('student-data').style.display = 'none'
        document.getElementById("new-search-btn").style.display = 'none'
        document.getElementById("new-search-label").innerHTML = 'Datos del estudiante en curso'

        displayHomePage()

        teteo123() 


    }
    catch(e){ alert("Error during the house Keeping. " + e)}
}

function processForm(){

    try{

        disableLogin()

        if(localStorage.getItem('SG') === null || localStorage.getItem('SG') === ''){
            alert('Todavía no se ha registrado ningún estudiante!!')
    
            return
        }
    
        showRegisterForm()
        displaySearchPage()
    }

    catch(e){ alert('Error while calling the processForm function - ' + e)}
}

function removeHomePageButtons(){

    try{

        disableLogin()

        document.getElementById('registerBtn').style.display = 'none';
        document.getElementById('viewBtn').style.display = 'none'
        document.getElementById('updateBtn').style.display = 'none'
        document.getElementById('deleteBtn').style.display = 'none'
        document.getElementById('search-btn').style.display = 'none'

        document.getElementById('backup-btn').style.display = 'none'
        document.getElementById('textarea').style.display = 'none'
        document.getElementById('recover-data-btn').style.display = 'none'
        document.getElementById('back-home').style.display = 'none'

        document.getElementById('register-btn').style.display = 'block'
        document.getElementById('home-btn').style.display = 'block'

    }

    catch(e){ alert("Error while removing buttons. " + e)}
}

function displayHomePage(){

    try{

        document.getElementById('register-btn').style.display = 'none'
        document.getElementById('register-btn1').style.display = 'none'
        document.getElementById('search-btn').style.display = 'none'
        document.getElementById('home-btn').style.display = 'none'

        document.getElementById("registrationForm").style.display = 'none'

        document.getElementById('backup-btn').style.display = 'block'
        document.getElementById('textarea').style.display = 'block'
        document.getElementById('recover-data-btn').style.display = 'block'
        document.getElementById('back-home').style.display = 'block'

        document.getElementById('registerBtn').style.display = 'block';
        document.getElementById('viewBtn').style.display = 'block'
        document.getElementById('updateBtn').style.display = 'block'
        document.getElementById('deleteBtn').style.display = 'block'

    }

    catch(e){ alert("Error while returning to the Home Page. " + e)}
}

function displaySearchPage(){

    try{

        document.getElementById('firstName').style.display = 'none'

        document.getElementById('lastName').style.display = 'none'
        document.getElementById('studentID').style.display = 'block'

        document.getElementById('branchlabel').style.display = 'none'
        document.getElementById('branch').style.display = 'none'

        document.getElementById('year1').style.display = 'none'
        document.getElementById('avg1').style.display = 'none'
        document.getElementById('subjectsy1s1').style.display = 'none'
        document.getElementById('subjectsy1s2').style.display = 'none'

        document.getElementById('year2').style.display = 'none'
        document.getElementById('avg2').style.display = 'none'
        document.getElementById('subjectsy2s1').style.display = 'none'
        document.getElementById('subjectsy2s2').style.display = 'none'

        document.getElementById('year3').style.display = 'none'
        document.getElementById('avg3').style.display = 'none'
        document.getElementById('subjectsy3s1').style.display = 'none'
        document.getElementById('subjectsy3s2').style.display = 'none'

        document.getElementById('firstnamelabel').style.display = 'none'

        document.getElementById('lastnamelabel').style.display = 'none'
        document.getElementById('studentlabel').style.display = 'none'

        document.getElementById('year1label').style.display = 'none'
        document.getElementById('subjectsy1s1label').style.display = 'none'
        document.getElementById('subjectsy1s2label').style.display = 'none'

        document.getElementById('year2label').style.display = 'none'
        document.getElementById('subjectsy2s1label').style.display = 'none'
        document.getElementById('subjectsy2s2label').style.display = 'none'

        document.getElementById('year3label').style.display = 'none'
        document.getElementById('subjectsy3s1label').style.display = 'none'
        document.getElementById('subjectsy3s2label').style.display = 'none'

        document.getElementById('register-btn').style.display = 'none'
        document.getElementById('register-btn1').style.display = 'none'

        document.getElementById('search-btn').style.display = 'block'
        document.getElementById('home-btn').style.display = 'block'

        disableLogin()

    }catch(e) { alert('Error after an attempt to retrieve student data - ' + e)}
}

function disableSearchPage(){

    try{

        disableLogin()

        if(document.getElementById('firstName').style.display === 'none'){

        document.getElementById('firstName').style.display = 'block'

        document.getElementById('lastName').style.display = 'block'
        document.getElementById('studentID').style.display = 'block'

        document.getElementById('branchlabel').style.display = 'block'
        document.getElementById('branch').style.display = 'block'

        document.getElementById('year1').style.display = 'block'
        document.getElementById('avg1').style.display = 'block'
        document.getElementById('subjectsy1s1').style.display = 'block'
        document.getElementById('subjectsy1s2').style.display = 'block'

        document.getElementById('year2').style.display = 'block'
        document.getElementById('avg2').style.display = 'block'
        document.getElementById('subjectsy2s1').style.display = 'block'
        document.getElementById('subjectsy2s2').style.display = 'block'

        document.getElementById('year3').style.display = 'block'
        document.getElementById('avg3').style.display = 'block'
        document.getElementById('subjectsy3s1').style.display = 'block'
        document.getElementById('subjectsy3s2').style.display = 'block'

        document.getElementById('firstnamelabel').style.display = 'block'

        document.getElementById('lastnamelabel').style.display = 'block'
        document.getElementById('studentlabel').style.display = 'block'

        document.getElementById('year1label').style.display = 'block'
        document.getElementById('subjectsy1s1label').style.display = 'block'
        document.getElementById('subjectsy1s2label').style.display = 'block'

        document.getElementById('year2label').style.display = 'block'
        document.getElementById('subjectsy2s1label').style.display = 'block'
        document.getElementById('subjectsy2s2label').style.display = 'block'

        document.getElementById('year3label').style.display = 'block'
        document.getElementById('subjectsy3s1label').style.display = 'block'
        document.getElementById('subjectsy3s2label').style.display = 'block'
        document.getElementById('home-btn').style.display = 'block'

        
        }

    }catch(e) { alert('Error after an attempt to disable the search page - ' + e)}
}

function processSubjectsAndGrades(sg){

    try{

        semesterAvg = 0
        denominator = 1

        if (sg[0] !== ''){

            denominator = 1*(1*(sg.length)-1)
        }

        for(let i=0; i<sg.length; i++){

            if(sg[i] !== '_' && sg[i] !== ''){
                semesterAvg = 1*semesterAvg + 1*((sg[i].replace(', ', ',')).split('-')[1])
            }

        }

        return semesterAvg/denominator

    }
    catch(e) { alert('Error processing Subjects and Grades - ' + e)}
}

function calculateYearAvg(){

    try{

        let firstName = document.getElementById('firstName').value;

        let lastName = document.getElementById('lastName').value
        let id = document.getElementById('studentID').value

        let branch = document.getElementById('branch').value

        let year1 = document.getElementById('year1').value
        let avg1 = document.getElementById('avg1').value
        let sy1s1 = document.getElementById('subjectsy1s1').value + ',_'
        let sy1s2 = document.getElementById('subjectsy1s2').value + ',_'

        let year2 = document.getElementById('year2').value
        let avg2 = document.getElementById('avg2').value
        let sy2s1 = document.getElementById('subjectsy2s1').value  + ',_'
        let sy2s2 = document.getElementById('subjectsy2s2').value + ',_'

        let year3 = document.getElementById('year3').value
        let avg3 = document.getElementById('avg3').value
        let sy3s1 = document.getElementById('subjectsy3s1').value  + ',_'
        let sy3s2 = document.getElementById('subjectsy3s2').value + ',_'

        let sy1s1Avg = processSubjectsAndGrades(sy1s1.split(','))
        let sy1s2Avg = processSubjectsAndGrades(sy1s2.split(','))
        let sy2s1Avg = processSubjectsAndGrades(sy2s1.split(','))
        let sy2s2Avg = processSubjectsAndGrades(sy2s2.split(','))
        let sy3s1Avg = processSubjectsAndGrades(sy3s1.split(','))
        let sy3s2Avg = processSubjectsAndGrades(sy3s2.split(','))

        if(sy1s2Avg !== 0) {
            avg1 = ((sy1s1Avg + sy1s2Avg)/2).toFixed(2)
        }

        else{
            avg1 = (1*sy1s1Avg).toFixed(2)
        }

        if (sy2s2Avg !== 0){
            avg2 = ((sy2s1Avg + sy2s2Avg)/2).toFixed(2)
        }
        else{
            avg2 = (1*sy2s1Avg).toFixed(2)
        }

        if(sy3s2Avg !== 0 ){
            avg3 = ((sy3s1Avg + sy3s2Avg)/2).toFixed(2)
        }
        else{
            avg3 = (1*sy3s1Avg).toFixed(2)
        }

        document.getElementById('avg1').value = 'Promedio: ' + avg1
        document.getElementById('avg2').value = 'Promedio: ' + avg2
        document.getElementById('avg3').value = 'Promedio: ' + avg3

        
        if (branch === '' && id === '' ){

            alert('No has introducido ni la cédula ni la rama. Tienes que introducir al menos uno de los dos!!')

            return
        }
        

        if (firstName === '' || lastName === '' ||
            year1 === '' || avg1 === '' || 
            sy1s1.replace(/,_/g, '') === '' ){

            alert('Tienes que introducir los datos del estudiante y TAMBIEN datos de las asignaturas del primer año. ' +
                  'Pulse Ok para seguir!!')

            return
        }

        if(id === '' && branch !== ''){

            id = (firstName + ' ' + lastName + '-' + branch).toUpperCase()

        }
        
        if (confirm("Pulse Ok, y luego en Registrar otra vez si la información proporcionada es correcta y desea " + 
                    "guardarla.\n\nDe lo contrario pulse en Cancel para rectificar, y luego pulse en Registrar " +
                    "nuevamente para guardar la información rectificada.") == true) {

                document.getElementById('register-btn').style.display = 'none'
                document.getElementById('register-btn1').style.display = 'block'

                currentData = id + ':name|' + firstName + 'apellido|' + lastName +
                              ' year1|' + year1 + 'avg1|' + avg1 + '[y1s1(' + sy1s1 + ')' + 'y1s2(' + sy1s2 + ')]' +
                              ' year2|' + year2 + 'avg2|' + avg2 + '[y2s1(' + sy2s1 + ')' + 'y2s2(' + sy2s2 + ')]' +
                              ' year3|' + year3 + 'avg3|' + avg3 + '[y3s1(' + sy3s1 + ')' + 'y3s2(' + sy3s2 + ')]='

                currentData = currentData.replace(/,_/g, '')
  
        } else {

            currentData = ''

            return
        }

    }

    catch(e) { alert("Error while verifying profile data - " + e)}

}

function getStudentsData(){

    try{

    let studentId = document.getElementById('studentID').value

    if (studentId === '' ){
            
        alert('Debes introducir un número de cédula o Id que sea válido!!. Inténtelo de nuevo.')
        return
    }

    let myData = filterSpecificData(studentId)

    if(myData === 'NOT EXIST'){
        return
    }

    document.getElementById("student-data").style.display = 'block'
    document.getElementById("registrationForm").style.display = 'none'
    document.getElementById("search-btn").style.display = 'none'
    document.getElementById("new-search-btn").style.display = 'block'

    let studentDataLabel = '<br>' + (document.getElementById("new-search-label").innerHTML).replace(/en curso/g, 'cuyo nombre, Id o cédula es: ' + studentId + '.<br>')

    fname = 'Nombre: ' + myData.split('=')[0] + '<br>'
    lastnamne = 'Apellido: ' + myData.split('=')[1] + '<br>'

    let branchName = 'Rama: ' + personBranch.toUpperCase() + '<br>'

    year1 = '<br>*Primer Año: ' + myData.split('=')[2] + '&nbsp;&nbsp;'
    avg1 = 'Promedio: ' + myData.split('=')[3] + '<br><br>'

    y1s1 = setDisplayedlabel('-Primer Semestre:<br>' + formatSubjects(myData.split('=')[4]) + '<br>', '-Primer Semestre:', '-Cursos Generales', studentId)
    y1s2 = setDisplayedlabel('-Segundo Semestre:<br>' + formatSubjects(myData.split('=')[5]) + '<br><br>', '-Segundo Semestre:', '<br>-Cursos de la Especialidad de Pastorado', studentId)

    year2 = setDisplayedlabel('*Segundo Año: ' + myData.split('=')[6] + '&nbsp;&nbsp;', '*Segundo Año: ', '', studentId)
    avg2 = setDisplayedlabel('Promedio: ' + myData.split('=')[7] + '<br><br>', 'Promedio: ' + myData.split('=')[7] + '<br><br>', '', studentId)

    y2s1 = setDisplayedlabel('-Primer Semestre:<br>' + formatSubjects(myData.split('=')[8]) + '<br><br>', '-Primer Semestre:', '-Cursos de la Especialidad de Evangelismo', studentId)
    y2s2 = setDisplayedlabel('-Segundo Semestre:<br> ' + formatSubjects(myData.split('=')[9]) + '<br>', '-Segundo Semestre:', '-Cursos de la Especialidad de Magisterio', studentId)

    year3 = setDisplayedlabel('<br>*Tercer Año: ' + myData.split('=')[10] + '&nbsp;&nbsp;', '*Tercer Año: ', '', studentId)
    avg3 = setDisplayedlabel('Promedio: ' + myData.split('=')[11] + '<br><br>', 'Promedio: ' + myData.split('=')[11] + '<br><br>', '', studentId)

    y3s1 = setDisplayedlabel('-Primer Semestre:<br>' + formatSubjects(myData.split('=')[12]) + '<br>', '-Primer Semestre:', '-Curso Electivo', studentId)
    y3s2 = setDisplayedlabel('-Segundo Semestre:<br>' + formatSubjects(myData.split('=')[13]) + '<br>', '-Segundo Semestre:', '<br>-Práctica', studentId)

    myData = fname + lastnamne + branchName +
    year1 + avg1 + y1s1 + y1s2 +
    year2 + avg2 + y2s1 + y2s2 +
    year3 + avg3 + y3s1 + y3s2

    let tmp = ''

    if (skill !== ''){

        if(personBranch === ''){

            if(isEmaic(studentId) === 0){
                alert('Nota: Este estudiante es miembro del ITAIC')

            }

            tmp =  getEmaicData(studentId)

            if(tmp.includes('|')) {
                tmp = tmp.split('|')[1]
            }
        }

        else{

            if(isEmaic((studentId + '-' + personBranch).toUpperCase()) === 0){
                alert('Nota: Este estudiante es miembro del ITAIC')
            }

            tmp =  getEmaicData((studentId + '-' + personBranch).toUpperCase())
            
            if(tmp.includes('|')) {
                tmp = tmp.split('|')[1]
            }
        }

        studentDataLabel = '<br><b><center>' + (tmp ).toUpperCase() + '</center></b>' + studentDataLabel
    }

    else {

        if(personBranch === ''){

            if(isEmaic(studentId) === 1){
                alert('*Nota: Este estudiante es miembro del EMAIC')

            }
        }

        else{

            if(isEmaic((studentId + '-' + personBranch).toUpperCase()) === 1){
                alert('*Nota: Este estudiante es miembro del EMAIC')
            }
        }
    }

    document.getElementById("new-search-label").innerHTML = '<b>' + studentDataLabel + '<br>' + myData + '</b><br>'

    }
    catch(e) { alert('Error getting students data - ' + e )}
}

function updateStudentsData(){

    try{

    let studentId = document.getElementById('studentID').value

    if (studentId === '' ){
            
        alert('Debes introducir un número de cédula o Id que sea válido!!. Inténtelo de nuevo.')
        return
    }

    let myData = filterSpecificData(studentId)

    if(myData === 'NOT EXIST'){
        return
    }

    document.getElementById("student-data").style.display = 'none'
    document.getElementById("registrationForm").style.display = 'block'
    document.getElementById("search-btn").style.display = 'none'
    document.getElementById("new-search-btn").style.display = 'none'
    document.getElementById("register-btn").style.display = 'block'

    disableSearchPage()

    document.getElementById("firstName").value = fname
    document.getElementById("lastName").value = lastnamne

    document.getElementById("year1").value = year1
    document.getElementById("avg1").value = avg1

    document.getElementById("subjectsy1s1").value = y1s1
    document.getElementById("subjectsy1s2").value = y1s2

    document.getElementById("year2").value = year2
    document.getElementById("avg2").value = avg2

    document.getElementById("subjectsy2s1").value = y2s1
    document.getElementById("subjectsy2s2").value = y2s2

    document.getElementById("year3").value = year3
    document.getElementById("avg3").value = avg3

    document.getElementById("subjectsy3s1").value = y3s1
    document.getElementById("subjectsy3s2").value = y3s2

    if(document.getElementById('branch').value !== ''){
        document.getElementById('studentID').value = ''
    }

    let tmp = ''

    if (skill !== ''){
        
        if(document.getElementById('branch').value === ''){

          if(isEmaic(studentId) === 0){
            alert('Nota: Este estudiante es miembro del ITAIC')

          }

          tmp =  getEmaicData(studentId).split('|')[1]
        }

        else{

          if(isEmaic((studentId + '-' + personBranch).toUpperCase()) === 0){
            alert('Nota: Este estudiante es miembro del ITAIC')
          }

          tmp =  getEmaicData((studentId + '-' + personBranch).toUpperCase())
    
          if(tmp.includes('|')) {
            tmp = tmp.split('|')[1]
          }
        }

        document.getElementById('expertise').value = tmp

        if (tmp === undefined || tmp === 'undefined'){

            document.getElementById('expertise').value = ''

        }
    }

    else{

        if(document.getElementById('branch').value === ''){

            if(isEmaic(studentId) === 1){
              alert('*Nota: Este estudiante es miembro del EMAIC')
  
            }
  
        }
  
        else{
  
          if(isEmaic((studentId + '-' + personBranch).toUpperCase()) === 1){
              alert('*Nota: Este estudiante es miembro del EMAIC')
          }

        }
  
    }

    disableLogin()
    setFormLabel(studentId)

    }
    catch(e) { alert('Error getting students data - ' + e )}
}

function deleteCurrentData(studentId){

    try{
        let myData = localStorage.getItem('SG')

        if(document.getElementById('studentID').value !== ''){
            studentId = document.getElementById('studentID').value
        }

        if(!myData.includes(studentId + ':')){

            if (studentId === 'dummyValue'){

                alert('Introduzca un Id ó cédula que sea válido!!')

            }
            else{

                studentId = filterSpecificData(studentId)

                if(studentId === 'NOT EXIST'){
                    return 'NOT EXIST'
                }

                else{
                    //----return studentId
                }

            }

            //===return 'NOT EXIST'
        
        }

        myData = studentId + ':' + myData.split(studentId + ':')[1].split('=')[0]

        if (skill !== ''){

          if(isEmaic(studentId) === 0){
        
            alert('Nota: Este estudiante es miembro del ITAIC')

          }
        }

        else{

           if(isEmaic(studentId) === 1){
        
                alert('*Nota: Este estudiante es miembro del EMAIC')
    
           }
        }

        if(searchUpdate === 2){
            
            if (confirm("El estudiante cuyo nombre, Id o cédula es " + studentId + " será borrado del sistema. " +
                    "Estás seguro que lo quieres borrar?") == true) {

                        localStorage.setItem('SG',(localStorage.getItem('SG')).replace(myData + '=', ''))
                        localStorage.setItem('skills', localStorage.getItem('skills').replace(getEmaicData(studentId), ''))

                        alert('El estudiante ' + studentId + ' ha sido borrado del sistema!!.')

            } else {
                return
            }
        }

        localStorage.setItem('SG',(localStorage.getItem('SG')).replace(myData + '=', ''))

    }
    catch(e) { alert('Error while deleting students data - ' + e )}
}

function formatSubjects(subjects){

    try{

        let subjectsList = ''
        let listOfSubjects = ''

        if(subjects.includes(',')){

            listOfSubjects = subjects.split(',')

            for(let i=0; i<listOfSubjects.length; i++){

                subjectsList = subjectsList + listOfSubjects[i] + '<br>'

            }
        }

        else{
            subjectsList = subjects
        }

        return subjectsList

    }
    catch(e) { alert('Error in formatSubjects function - ' + e )}
}

function filterSpecificData(studentId){

    try{

        let myData = localStorage.getItem('SG')
        personBranch = ''

        if(!myData.includes(studentId + ':')){

            if(!isNaN(studentId.replace(/ /g, '').replace(/-/g, '').replace(/_/g, '').replace(/\./g, ''))
            || studentId.includes('-') || studentId.includes('_')){

                alert('El nombre, rama, Id o la cédula, ' + studentId + ', no existe en el sistema. Inténtelo de nuevo')
                return 'NOT EXIST'
            }

            personBranch = prompt("El estudiante, " + 
                                studentId + ", no aparece en el sistema. " +
                                "Favor de introducir la rama para localizarlo.", "INTRODUCIR RAMA");

            if (personBranch === 'INTRODUCIR RAMA'){
                alert('DEBES INTRODUCIR EL NOMBRE DE LA RAMA!!')
                return 'NOT EXIST'
            }

            else if (personBranch !== null && personBranch !== '') {

                studentId = (studentId + '-' + personBranch).toUpperCase()

            }

            else {
                return 'NOT EXIST'
            }

            if(!myData.includes(studentId + ':')){
                
                alert('El estudiante, ' + studentId.split('-')[0] + ', cuya rama es ' + personBranch +
                      ' no existe en el sistema.\n' + 
                      '\nRecuerde que para buscar un estudiante por nombre, ' +
                      'hay que introducir tanto el nombre como el apellido.\n\nInténtelo de nuevo!!')

                return 'NOT EXIST'
            }
        
        }

        if(searchUpdate === 2) {
            return studentId
        }

        else if (searchUpdate === 1){
            document.getElementById('branch').value = personBranch.toUpperCase()
        }

        myData = studentId + ':' + myData.split(studentId + ':')[1].split('=')[0]

        fname = myData.split('name|')[1].split('apellido')[0]
        lastnamne = myData.split('apellido|')[1].split(' year1')[0]

        year1 = myData.split('year1|')[1].split('avg1')[0]
        avg1 = myData.split('avg1|')[1].split('[')[0]
        y1s1 = myData.split('y1s1(')[1].split(')')[0]
        y1s2 = myData.split('y1s2(')[1].split(')')[0]

        year2 = myData.split('year2|')[1].split('avg2')[0]
        avg2 = myData.split('avg2|')[1].split('[')[0]
        y2s1 = myData.split('y2s1(')[1].split(')')[0]
        y2s2 = myData.split('y2s2(')[1].split(')')[0]

        year3 = myData.split('year3|')[1].split('avg3')[0]
        avg3 = myData.split('avg3|')[1].split('[')[0]
        y3s1 = myData.split('y3s1(')[1].split(')')[0]
        y3s2 = myData.split('y3s2(')[1].split(')')[0]

        myData = fname + '=' + lastnamne + '=' + 
                 year1 + '=' + avg1 + '=' + y1s1 + '=' + y1s2 + '=' +
                 year2 + '=' + avg2 + '=' + y2s1 + '=' + y2s2 + '=' +
                 year3 + '=' + avg3 + '=' + y3s1 + '=' + y3s2
                
        return myData

    }
    catch(e) { alert('Error filtering specific students data - ' + e )}
}

function saveProfile(){

    try{

        calculateYearAvg()
        disableLogin()

    }
    catch(e) { alert('Error saving profile - ' + e)}
}

function backUp(){

    try{

        let sgCounter = localStorage.getItem('SG');
  
        if(sgCounter === '' || sgCounter === null){
          alert('No hay nada que guardar. No hay datos en el sistema!!. Pulse Ok para seguir.')
          return
        }
  
        const link = document.createElement("a");
  
        // Create a blog object with the file content which you want to add to the file
        const file = new Blob([sgCounter], { type: 'text/plain' });
  
        // Add file content in the object URL
        link.href = URL.createObjectURL(file);
  
        // Add file name
        link.download = "gestoria de estudiantes_copia-de-datos.txt";
  
        // Add click event to <a> tag to save file.
        link.click();
        URL.revokeObjectURL(link.href);

    }
    catch(e) { alert('Error creating Backup - ' + e)}
}

function teteo123()
{
    try{

        if(fstTime === null || fstTime === ''){
            fstTime = 0
            localStorage.setItem('ft', 0)
        }
        else if (1*fstTime !== 0){
            fstTime = localStorage.getItem('ft')

        }

        if((1*fstTime === 0) || (localStorage.getItem(('mdfgdgó345./&@#-346dfgg6781<zcxvc4éastdfgdgó345./&@#-346dfgg6781<zcxvc4éer-dfgdgó345./&@#-346dfgg6781<zcxvc4ékdfgdgó345./&@#-346dfgg6781<zcxvc4éedfgdgó345./&@#-346dfgg6781<zcxvc4éy').replace(/dfgdgó345\.\/\&\@\#-346dfgg6781<zcxvc4é/g, '')) === '') || (localStorage.getItem(('mdfgdgó345./&@#-346dfgg6781<zcxvc4éastdfgdgó345./&@#-346dfgg6781<zcxvc4éer-dfgdgó345./&@#-346dfgg6781<zcxvc4ékdfgdgó345./&@#-346dfgg6781<zcxvc4éedfgdgó345./&@#-346dfgg6781<zcxvc4éy').replace(/dfgdgó345\.\/\&\@\#-346dfgg6781<zcxvc4é/g, '')) === null)){

            if (confirm("Eres el administrador o el dueño de este programa?. \n\n" +
                        "Pulse Ok si es así. \n\nDe lo contrario pulse Cancelar") == true) {

                keloke = prompt(("E.s.c.r.i.be. t.u n.ombre y a.p.ellido c.o.m.pletos").replace(/\./g, ''));

                if (keloke.toLowerCase() !== ('bdfgdgó345./&@#-346dfgg6781<zcxvc4éendfgdgó345./&@#-346dfgg6781<zcxvc4éito dfgdgó345./&@#-346dfgg6781<zcxvc4éddfgdgó345./&@#-346dfgg6781<zcxvc4ée ldfgdgó345./&@#-346dfgg6781<zcxvc4éa rdfgdgó345./&@#-346dfgg6781<zcxvc4éosdfgdgó345./&@#-346dfgg6781<zcxvc4éa pdfgdgó345./&@#-346dfgg6781<zcxvc4édfgdgó345./&@#-346dfgg6781<zcxvc4éérdfgdgó345./&@#-346dfgg6781<zcxvc4éedfgdgó345./&@#-346dfgg6781<zcxvc4ézdfgdgó345./&@#-346dfgg6781<zcxvc4é').replace(/dfgdgó345\.\/\&\@\#-346dfgg6781<zcxvc4é/g, '')){
                    alert('O el nombre o el apellido o los dos no están bien escritos.\nPulse Ok para cerrar e intentarlo de nuevo')
                    localStorage.setItem('ft', 0)
                    closeApp()
                    return
                }
            

                keloke = prompt(("C.ua.l e.s e.l n.o.mbre d.e t.u p.a.pá?").replace(/\./g, ''));

                if (keloke.toLowerCase() !== ('bdfgdgó345./&@#-346dfgg6781<zcxvc4éendfgdgó345./&sbdfgdgó345./&@#-346dfgg6781<zcxvc4éendfgdgó345./&ibdfgdgó345./&@#-346dfgg6781<zcxvc4éendfgdgó345./&mbdfgdgó345./&@#-346dfgg6781<zcxvc4éendfgdgó345./&ebdfgdgó345./&@#-346dfgg6781<zcxvc4éendfgdgó345./&óbdfgdgó345./&@#-346dfgg6781<zcxvc4éendfgdgó345./&nbdfgdgó345./&@#-346dfgg6781<zcxvc4éendfgdgó345./&').replace(/bdfgdgó345\.\/\&\@\#-346dfgg6781<zcxvc4éendfgdgó345\.\/\&/g, '')){
                    alert(('E.se n.o es el no.m.bre!!- P.ulse O.k pa.ra ce.rrar e in.ten.tarlo d.e n.u.evo').replace(/\./g, '').replace(/-/g, '.'))
                    localStorage.setItem('ft', 0)
                    closeApp()
                    return
                }

                keloke = prompt(("Cu.al e.s la contr.aseñ.a ma.es.tra que te di.ó Cr.i.s.=").replace(/\./g, '').replace(/=/g, '?'));

                if (keloke.toLowerCase() !== ('bdfgdgó345./&@#-346dfgg6781<zcxvc4éendfgdgó345./&tbdfgdgó345./&@#-346dfgg6781<zcxvc4éendfgdgó345./&abdfgdgó345./&@#-346dfgg6781<zcxvc4éendfgdgó345./&tbdfgdgó345./&@#-346dfgg6781<zcxvc4éendfgdgó345./&abdfgdgó345./&@#-346dfgg6781<zcxvc4éendfgdgó345./&bdfgdgó345./&@#-346dfgg6781<zcxvc4éendfgdgó345./&cbdfgdgó345./&@#-346dfgg6781<zcxvc4éendfgdgó345./&ubdfgdgó345./&@#-346dfgg6781<zcxvc4éendfgdgó345./&cbdfgdgó345./&@#-346dfgg6781<zcxvc4éendfgdgó345./&a2bdfgdgó345./&@#-346dfgg6781<zcxvc4éendfgdgó345./&0bdfgdgó345./&@#-346dfgg6781<zcxvc4éendfgdgó345./&0bdfgdgó345./&@#-346dfgg6781<zcxvc4éendfgdgó345./&6bdfgdgó345./&@#-346dfgg6781<zcxvc4éendfgdgó345./&').replace(/bdfgdgó345\.\/&@#-346dfgg6781<zcxvc4éendfgdgó345\.\/&/g, '')){
                    alert(('E.s.a n.o e.s l.a c.o.ntr.as.e.ña!!- P.u.ls.e .Ok p.ar.a c.er.rar e. i.n.tenta.rlo d.e n.uevo').replace(/\./g, '').replace(/-/g, '.'))
                    localStorage.setItem('ft', 0)
                    closeApp()
                    return
                }

                keloke1 = prompt(("E.sc.ri.b.e la cl.ave q.ue us.ará la ot.ra pe.rs.ona qu.e tra.b.ajará c.on el p.rog.rama en es.ta P.C").replace(/\./g, ''));
                keloke2 = prompt(("R.ep.ite l.a c.l.ave").replace(/\./g, ''));

                if(keloke1 === '' && keloke2 === ''){

                    alert('Error!!. Tienes que introducir una clave. Y repetirla')

                    keloke1 = prompt(("E.sc.ri.b.e la cl.ave q.ue us.ará la ot.ra pe.rs.ona qu.e tra.b.ajará c.on el p.rog.rama en es.ta P.C").replace(/\./g, ''));
                    keloke2 = prompt(("R.ep.ite l.a c.l.ave").replace(/\./g, ''));

                    if(keloke1 === '' && keloke2 === ''){
                        alert('Error otra vez!!. Pulse aceptar para cerrar. Luego si lo deseas puedes empezar de nuevo!!')
                        localStorage.setItem('ft', 0)
                        closeApp()
                        return
                    }


                }

                if(keloke2 === keloke1){
                    alert(('Y.a est.á todo se.te.ado. La cl.ave pa.ra tra.bajar co.n es.te pro.grama  e.n es.ta P.C es "' + keloke2 +
                          '".\n\nNo se ol.vide de ent.re.gársela a la pers.ona q.ue tra.baja.rá con el progr.ama e.n es.te P.C-' +
                          '\n\nPul.se Ace.ptar pa.ra seguir---').replace(/\./g, '').replace(/-/g, '.'))

                    localStorage.setItem(('mbdfgdgó345./&@#-346dfgg6781<zcxvc4éendfgdgó345./&asbdfgdgó345./&@#-346dfgg6781<zcxvc4éendfgdgó345./&terbdfgdgó345./&@#-346dfgg6781<zcxvc4éendfgdgó345./&-kebdfgdgó345./&@#-346dfgg6781<zcxvc4éendfgdgó345./&y').replace(/bdfgdgó345\.\/\&\@\#-346dfgg6781<zcxvc4éendfgdgó345\.\/\&/g, ''), ('bdfgdgó345./&@#-346dfgg6781<zcxvc4éendfgdgó345./&tabdfgdgó345./&@#-346dfgg6781<zcxvc4éendfgdgó345./&tacbdfgdgó345./&@#-346dfgg6781<zcxvc4éendfgdgó345./&ucbdfgdgó345./&@#-346dfgg6781<zcxvc4éendfgdgó345./&a2bdfgdgó345./&@#-346dfgg6781<zcxvc4éendfgdgó345./&0bdfgdgó345./&@#-346dfgg6781<zcxvc4éendfgdgó345./&0bdfgdgó345./&@#-346dfgg6781<zcxvc4éendfgdgó345./&6bdfgdgó345./&@#-346dfgg6781<zcxvc4éendfgdgó345./&').replace(/bdfgdgó345\.\/\&\@\#-346dfgg6781<zcxvc4éendfgdgó345\.\/\&/g, '') + '-' + keloke2)
                    localStorage.setItem('ft', 1)
                    closeApp()

                }

                else{

                    alert(('N.o rep.eti.ste la mi.sma cl.ave- Pu.lse O.k e int.éntelo d.e nu.evo!!').replace(/\./g, '').replace(/-/g, '.'))
                    localStorage.setItem('ft', 0)
                    closeApp()
                    return

                }

                document.getElementById("initial-page").style.display = 'none'
                document.getElementById("logo-page").style.display = 'block'

                document.getElementById("emaic").style.display = 'block'
                document.getElementById("itaic").style.display = 'block'

            }

            else{

                alert('Sólo el dueño puede instalar el programa. Pulse Ok para cerrar!!')
                
                localStorage.setItem('ft', 0)
                closeApp()
                return

            }

        }

        else if(1*fstTime === 1){

            dimeAve = prompt("Inserte la clave para entrar en el programa");

            if (!localStorage.getItem('master-key').includes(dimeAve) || localStorage.getItem('master-key') === ''){

              alert('La clave no es correcta. Pulse Ok para cerrar. \n\nLuego inténtelo de nuevo si lo desea!!')

              localStorage.setItem('ft', 1)
              closeApp()
              return

            }

            else {
                document.getElementById("initial-page").style.display = 'none'
                document.getElementById("logo-page").style.display = 'block'

                document.getElementById("emaic").style.display = 'block'
                document.getElementById("itaic").style.display = 'block'

                localStorage.setItem('ft', 2)
                //return
            }

        }

        else{

            document.getElementById("initial-page").style.display = 'none'
            document.getElementById("logo-page").style.display = 'block'

            document.getElementById("emaic").style.display = 'block'
            document.getElementById("itaic").style.display = 'block'

            localStorage.setItem('ft', 2)

        }


    }catch(e) { alert('Exception while calling teteo - ' + e)
                closeApp()
              }
}
function disableLogin(){

    try{
        
        if(1*fstTime === 1){

            fstTime = 2
            localStorage.setItem('ft', 2)
        }

    } catch(e){ alert('Exception - disableLogin -> ' + e)}
}
function closeApp(){

    window.location.href = "javascript:window.open('','_self').close();"
    return false

}

function dataRecovery(){

    try{

        let textAreaContent = document.getElementById('textarea').value

        if (textAreaContent === '' || textAreaContent === null){
            alert('Copie los datos del archivo que contiene los datos que usted desea recuperar en el area en blanco.')
            return
        }

        else if (!textAreaContent.includes(':') || !textAreaContent.includes('=') ||
                 !textAreaContent.includes('y1s1') || !textAreaContent.includes('year1') ||
                 !textAreaContent.includes('y1s2') || !textAreaContent.includes('year1') ||
                 !textAreaContent.includes('y2s1') || !textAreaContent.includes('year2') ||
                 !textAreaContent.includes('y3s1') || !textAreaContent.includes('year3') ){

                    alert('Copie en el area en blanco un contenido válido. Asegúrese de que el contenido ' +
                          'procede de un archivo generado para guardar datos que usted ha insertado en el sistema.')

                          return

        }

        else{
            localStorage.setItem('SG', document.getElementById('textarea').value)
            alert('Sus datos han sido recuperados desde el contenido que usted copió en el area en blanco!!')
            document.getElementById('textarea').value = ''

        }
    }
    catch(e) { alert('Error while recovering data - ' + e)}
}

function displayLogoPage(){

    try{

      document.getElementById("initial-page").style.display = 'none'
      document.getElementById("logo-page").style.display = 'block'

      document.getElementById("itaic").style.display = 'block'
      document.getElementById("emaic").style.display = 'block'
      document.getElementById("emaic-options-page").style.display = 'none'

      skill = ''

    } catch(e) { alert('Exception while calling the diaplayLogoPage function -->> ' + e)}
}

function displayEmaicMenu(expertise) {

    try {
        document.getElementById("initial-page").style.display = 'block'
        document.getElementById("emaic-options-page").style.display = 'none'

        skill = (skill + ' - ' + expertise).replace(/-btn/g, '')

    } catch (error) { alert('Problems when calling the displayEmaicMenu function ---->> ' + error)}
}

function getEmaicData(studentId){

    try {

        if (!localStorage.getItem('skills').includes(studentId)){
            return 'No Specialidad Definida en EMAIC'
        }

        let allSkills = localStorage.getItem('skills') + '==='

        let currentSkill = allSkills.split('===' + studentId + '|')[1].split('===')[0]

        return '===' + studentId + '|' + currentSkill
        
    } catch (e) { alert('Exception calling getEmaicData ---->>> ' + e)}
}

function isEmaic(studentID){

    try {

        if (!localStorage.getItem('skills').includes(studentID)){
            return 0
        }

        else {
            return 1
        }
        
    } catch (error) {
        alert('Error calling isEmaic() --->>> ' + error)
        
    }
}

function setDisplayedlabel(currentLabel, source, destination, studentId){

    try {

        if (skill !== '' && source !== '' && destination !== '' && isEmaic(studentId) === 1 || 
           (isEmaic(studentId) === 1) || (localStorage.getItem('skills').includes(studentId.toUpperCase() + '-')))
        {
           
            return currentLabel = currentLabel.replace(source, destination)

        }

        else if (skill === '' || (isEmaic(studentId) === 0)){

            return currentLabel
        }

        else{
            return ''
        }
        
    } catch (error) { alert('Error - setDisplayedLabel function --->>> ' + error) }
}

function setFormLabel(studentId){

    try{

         if (localStorage.getItem('skills').includes(studentId) && studentId !== '' ||
            (skill !== '' && localStorage.getItem('skills').includes(studentId) && studentId !== '') ||
            (studentId !== '' && localStorage.getItem('skills').includes(studentId.toUpperCase() + 
            '-' ) ) || (skill !== '' && studentId === '') ){

            document.getElementById("expertise").style.display = 'block'
            document.getElementById('expertiselabel').style.display = 'block'
    
            document.getElementById('expertise').value = skill.toUpperCase()
    
            document.getElementById('year2label').style.display = 'none'
            document.getElementById('year3label').style.display = 'none'
    
            document.getElementById('year2').style.display = 'none'
            document.getElementById('year3').style.display = 'none'
    
            document.getElementById('avg2').style.display = 'none'
            document.getElementById('avg3').style.display = 'none'
    
            document.getElementById('subjectsy1s1label').innerHTML = 'Cursos Generales'
            document.getElementById('subjectsy1s2label').innerHTML = 'Cursos de la Especialidad Pastorado'
            document.getElementById('subjectsy2s1label').innerHTML = 'Cursos de de la Especialidad Evangelismo'
            document.getElementById('subjectsy2s2label').innerHTML = 'Cursos de la Especialidad Magisterio'
            document.getElementById('subjectsy3s1label').innerHTML = 'Curso Electivo'
            document.getElementById('subjectsy3s2label').innerHTML = 'Practica'
    
        }
    
        else{

            document.getElementById("expertise").style.display = 'none'
            document.getElementById('expertiselabel').style.display = 'none'
    
            document.getElementById('year2label').style.display = 'block'
            document.getElementById('year3label').style.display = 'block'
    
            document.getElementById('year2label').innerHTML = '** Segundo Año:'
            document.getElementById('year3label').innerHTML = '*** Tercer Año:'
            
            document.getElementById('year2').style.display = 'block'
            document.getElementById('year3').style.display = 'block'
            
            document.getElementById('avg2').style.display = 'block'
            document.getElementById('avg3').style.display = 'block'
            
            document.getElementById('subjectsy1s1label').innerHTML = 'Primer Semestre:'
            document.getElementById('subjectsy1s2label').innerHTML = 'Segundo Semestre:'
            document.getElementById('subjectsy2s1label').innerHTML = 'Primer Semestre:'
            document.getElementById('subjectsy2s2label').innerHTML = 'Segundo Semestre:'
            document.getElementById('subjectsy3s1label').innerHTML = 'Primer Semestre:'
            document.getElementById('subjectsy3s2label').innerHTML = 'Segundo Semestre:'
        }
      //}   

    } catch(e){ console.log('Exception - setFormLabel() ---- >>' + e)}
}